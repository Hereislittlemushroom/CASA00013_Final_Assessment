Hi Reads,



If there are any issues in `Restart Kernel and Run All`, you can access the **Notebook** OR **Markdown** file as given below:

- The **Reproducible Analysis & Executive Briefing** are included in the [Notebook](https://github.com/Hereislittlemushroom/CASA0013_Final_Assessment/blob/main/Assessment%233_Data-Led_Executive_Briefing.ipynb)

- If you cannot see the result in the Notebook, you can see the same contents in this [Markdown file](https://github.com/Hereislittlemushroom/CASA0013_Final_Assessment/blob/main/Assessment%233_Data-Led_Executive_Briefing.md)



Have a good day :-)

Franklin